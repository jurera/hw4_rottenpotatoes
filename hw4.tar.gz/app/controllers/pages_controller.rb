class PagesController < ApplicationController
  def home
  end

  def contact
  end

end
